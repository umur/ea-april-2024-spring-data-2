create
    definer = root@`%` procedure GenerateUsers()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 100 DO
        INSERT INTO temp_users (email, password, first_name, last_name)
        VALUES (CONCAT('user', i, '@example.com'),
                CONCAT('password', i),
                CONCAT('FirstName', i),
                CONCAT('LastName', i));
        SET i = i + 1;
END WHILE;
END;


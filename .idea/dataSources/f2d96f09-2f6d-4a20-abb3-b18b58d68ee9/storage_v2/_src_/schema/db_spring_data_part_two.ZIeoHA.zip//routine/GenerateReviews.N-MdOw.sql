create
    definer = root@`%` procedure GenerateReviews()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 1000 DO
        INSERT INTO temp_reviews (comment, id_user, id_product)
        VALUES (CONCAT('Review ', i),
                (SELECT id FROM temp_users ORDER BY RAND() LIMIT 1),
                (SELECT id FROM temp_products ORDER BY RAND() LIMIT 1));
        SET i = i + 1;
END WHILE;
END;


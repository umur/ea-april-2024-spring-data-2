create
    definer = root@`%` procedure GenerateProducts()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 1000 DO
        INSERT INTO temp_products (name, price, rating)
        VALUES (CONCAT('Product ', i),
                ROUND(RAND() * 1000 + 10, 2),
                FLOOR(RAND() * 5) + 1);
        SET i = i + 1;
END WHILE;
END;

